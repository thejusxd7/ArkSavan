const BASE_URL = "https://api.jamendo.com/v3.0";

async function request(clientId, path, params) {
  const qs = new URLSearchParams({ client_id: clientId, format: "json", ...params });
  const res = await fetch(`${BASE_URL}/${path}/?${qs.toString()}`);
  if (!res.ok) throw new Error("Network request failed");
  const data = await res.json();
  if (data.headers && data.headers.status === "failed") {
    throw new Error(data.headers.error_message || "Jamendo API error");
  }
  return data.results || [];
}

export function fetchTrending(clientId, limit = 30) {
  return request(clientId, "tracks", {
    limit: String(limit),
    order: "popularity_total",
    imagesize: "200",
  });
}

export function searchTracks(clientId, query, limit = 30) {
  return request(clientId, "tracks", {
    limit: String(limit),
    search: query,
    imagesize: "200",
  });
}

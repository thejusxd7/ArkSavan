import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Slider from "@react-native-community/slider";
import { usePlayer } from "../context/PlayerContext";
import { colors } from "../theme";

function fmtTime(s) {
  if (!isFinite(s) || s < 0) return "0:00";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

export default function PlayerBar() {
  const { current, isPlaying, position, duration, togglePlay, playNext, playPrev, seekTo } = usePlayer();

  return (
    <View style={styles.bar}>
      <Image source={{ uri: current ? current.image : undefined }} style={styles.art} />
      <View style={styles.info}>
        <Text numberOfLines={1} style={styles.title}>{current ? current.name : "Nothing playing"}</Text>
        <Text numberOfLines={1} style={styles.artist}>{current ? current.artist_name : "Pick a track to start"}</Text>
      </View>
      <View style={styles.controls}>
        <TouchableOpacity onPress={playPrev} hitSlop={8}>
          <Ionicons name="play-skip-back" size={20} color={colors.paper} />
        </TouchableOpacity>
        <TouchableOpacity onPress={togglePlay} style={styles.playBtn} hitSlop={8}>
          <Ionicons name={isPlaying ? "pause" : "play"} size={18} color={colors.ink} />
        </TouchableOpacity>
        <TouchableOpacity onPress={playNext} hitSlop={8}>
          <Ionicons name="play-skip-forward" size={20} color={colors.paper} />
        </TouchableOpacity>
      </View>
      <View style={styles.sliderRow}>
        <Text style={styles.time}>{fmtTime(position)}</Text>
        <Slider
          style={{ flex: 1, height: 24 }}
          minimumValue={0}
          maximumValue={duration || 1}
          value={position}
          minimumTrackTintColor={colors.amber}
          maximumTrackTintColor={colors.line}
          thumbTintColor={colors.amber}
          onSlidingComplete={seekTo}
        />
        <Text style={styles.time}>{fmtTime(duration)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: { backgroundColor: colors.panel, borderTopWidth: 1, borderTopColor: colors.line, paddingHorizontal: 16, paddingTop: 10, paddingBottom: 6 },
  art: { width: 40, height: 40, borderRadius: 4, backgroundColor: "#222", position: "absolute", left: 16, top: 10 },
  info: { marginLeft: 52, marginBottom: 6 },
  title: { color: colors.paper, fontSize: 13, fontWeight: "500" },
  artist: { color: colors.textMuted, fontSize: 11, marginTop: 1 },
  controls: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 22, marginBottom: 2 },
  playBtn: { backgroundColor: colors.amber, width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  sliderRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  time: { color: colors.textMuted, fontSize: 10, minWidth: 28, textAlign: "center" },
});

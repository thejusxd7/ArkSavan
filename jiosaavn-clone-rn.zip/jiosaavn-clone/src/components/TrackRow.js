import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../theme";

function fmtTime(s) {
  if (!isFinite(s) || s < 0) return "0:00";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

export default function TrackRow({ track, isActive, isPlaying, onPress, onQueue, onLike, liked }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.row, isActive && styles.rowActive]} activeOpacity={0.7}>
      <Image source={{ uri: track.image }} style={styles.art} />
      <View style={styles.info}>
        <Text numberOfLines={1} style={[styles.title, isActive && styles.titleActive]}>{track.name}</Text>
        <Text numberOfLines={1} style={styles.artist}>{track.artist_name}</Text>
      </View>
      {isActive && isPlaying && <Ionicons name="volume-medium" size={16} color={colors.amber} style={{ marginRight: 4 }} />}
      <TouchableOpacity onPress={onLike} hitSlop={8} style={styles.iconBtn}>
        <Ionicons name={liked ? "heart" : "heart-outline"} size={18} color={liked ? colors.amber : colors.textMuted} />
      </TouchableOpacity>
      <TouchableOpacity onPress={onQueue} hitSlop={8} style={styles.iconBtn}>
        <Ionicons name="add" size={20} color={colors.textMuted} />
      </TouchableOpacity>
      <Text style={styles.duration}>{fmtTime(track.duration)}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", paddingVertical: 8, paddingHorizontal: 10, borderRadius: 8 },
  rowActive: { backgroundColor: "rgba(217,142,44,0.12)" },
  art: { width: 44, height: 44, borderRadius: 4, backgroundColor: "#222" },
  info: { flex: 1, marginLeft: 12, marginRight: 6 },
  title: { color: colors.paper, fontSize: 14, fontWeight: "500" },
  titleActive: { color: colors.amber },
  artist: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  iconBtn: { padding: 4, marginLeft: 2 },
  duration: { color: colors.textMuted, fontSize: 12, marginLeft: 6, minWidth: 34, textAlign: "right" },
});

export const colors = {
  ink: "#14110F",
  panel: "#1D1916",
  paper: "#F3EEE4",
  amber: "#D98E2C",
  amberDim: "#8A5E1F",
  textMuted: "rgba(243,238,228,0.5)",
  line: "rgba(243,238,228,0.12)",
};

import React, { createContext, useContext, useState, useRef, useCallback, useEffect } from "react";
import { Audio } from "expo-av";

const PlayerContext = createContext(null);

export function PlayerProvider({ children }) {
  const soundRef = useRef(null);
  const [queue, setQueue] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [current, setCurrent] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [liked, setLiked] = useState({});

  useEffect(() => {
    Audio.setAudioModeAsync({
      staysActiveInBackground: true,
      playsInSilentModeIOS: true,
      shouldDuckAndroid: true,
    });
  }, []);

  const onStatusUpdate = useCallback((status) => {
    if (!status.isLoaded) return;
    setPosition(status.positionMillis / 1000);
    setDuration((status.durationMillis || 0) / 1000);
    setIsPlaying(status.isPlaying);
    if (status.didJustFinish) {
      playNextRef.current();
    }
  }, []);

  async function loadAndPlay(track) {
    if (soundRef.current) {
      await soundRef.current.unloadAsync();
      soundRef.current = null;
    }
    const { sound } = await Audio.Sound.createAsync(
      { uri: track.audio },
      { shouldPlay: true },
      onStatusUpdate
    );
    soundRef.current = sound;
  }

  function playList(list, index) {
    setQueue(list);
    setCurrentIndex(index);
    setCurrent(list[index]);
    loadAndPlay(list[index]);
  }

  const playNextRef = useRef(() => {});
  function playNext() {
    if (!queue.length) return;
    const next = currentIndex + 1 < queue.length ? currentIndex + 1 : 0;
    setCurrentIndex(next);
    setCurrent(queue[next]);
    loadAndPlay(queue[next]);
  }
  playNextRef.current = playNext;

  function playPrev() {
    if (!queue.length) return;
    const prev = currentIndex - 1 >= 0 ? currentIndex - 1 : queue.length - 1;
    setCurrentIndex(prev);
    setCurrent(queue[prev]);
    loadAndPlay(queue[prev]);
  }

  async function togglePlay() {
    if (!soundRef.current) {
      if (current) loadAndPlay(current);
      return;
    }
    const status = await soundRef.current.getStatusAsync();
    if (status.isPlaying) await soundRef.current.pauseAsync();
    else await soundRef.current.playAsync();
  }

  async function seekTo(seconds) {
    if (!soundRef.current) return;
    await soundRef.current.setPositionAsync(seconds * 1000);
  }

  function addToQueue(track) {
    setQueue((q) => [...q, track]);
  }

  function toggleLike(track) {
    setLiked((l) => ({ ...l, [track.id]: !l[track.id] }));
  }

  useEffect(() => {
    return () => {
      if (soundRef.current) soundRef.current.unloadAsync();
    };
  }, []);

  return (
    <PlayerContext.Provider
      value={{
        queue,
        current,
        currentIndex,
        isPlaying,
        position,
        duration,
        liked,
        playList,
        playNext,
        playPrev,
        togglePlay,
        seekTo,
        addToQueue,
        toggleLike,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used within PlayerProvider");
  return ctx;
}

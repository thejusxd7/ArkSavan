import React, { useState, useEffect, useCallback } from "react";
import {
  View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, Linking, SafeAreaView, KeyboardAvoidingView, Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import TrackRow from "../components/TrackRow";
import PlayerBar from "../components/PlayerBar";
import { usePlayer } from "../context/PlayerContext";
import { fetchTrending, searchTracks } from "../api/jamendo";
import { colors } from "../theme";

const STORAGE_KEY = "jamendo_client_id";

export default function HomeScreen() {
  const [clientId, setClientId] = useState(null);
  const [clientIdInput, setClientIdInput] = useState("");
  const [checking, setChecking] = useState(true);

  const [query, setQuery] = useState("");
  const [trending, setTrending] = useState([]);
  const [results, setResults] = useState([]);
  const [view, setView] = useState("trending");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const { current, currentIndex, isPlaying, liked, playList, addToQueue, toggleLike } = usePlayer();

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((v) => {
      if (v) setClientId(v);
      setChecking(false);
    });
  }, []);

  useEffect(() => {
    if (!clientId) return;
    setLoading(true);
    fetchTrending(clientId)
      .then((r) => { setTrending(r); setLoading(false); })
      .catch((e) => { setError(e.message); setLoading(false); });
  }, [clientId]);

  const doSearch = useCallback(async () => {
    if (!clientId || !query.trim()) return;
    setLoading(true);
    setError(null);
    setView("search");
    try {
      const r = await searchTracks(clientId, query);
      setResults(r);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }, [clientId, query]);

  async function saveClientId() {
    const id = clientIdInput.trim();
    if (!id) return;
    await AsyncStorage.setItem(STORAGE_KEY, id);
    setClientId(id);
  }

  if (checking) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator color={colors.amber} />
      </SafeAreaView>
    );
  }

  if (!clientId) {
    return (
      <SafeAreaView style={styles.container}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.setupWrap}>
          <Ionicons name="disc" size={40} color={colors.amber} style={{ marginBottom: 16 }} />
          <Text style={styles.setupTitle}>Connect a Jamendo API key</Text>
          <Text style={styles.setupBody}>
            This app streams real, licensed tracks via Jamendo's free API. Get a client ID at
            devportal.jamendo.com — takes about two minutes, no cost.
          </Text>
          <TouchableOpacity onPress={() => Linking.openURL("https://devportal.jamendo.com")}>
            <Text style={styles.link}>Open devportal.jamendo.com</Text>
          </TouchableOpacity>
          <TextInput
            value={clientIdInput}
            onChangeText={setClientIdInput}
            placeholder="Paste your client ID"
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            autoCapitalize="none"
            autoCorrect={false}
          />
          <TouchableOpacity onPress={saveClientId} style={styles.connectBtn}>
            <Text style={styles.connectBtnText}>Connect</Text>
          </TouchableOpacity>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  const list = view === "search" ? results : trending;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="disc" size={22} color={colors.amber} />
        <View style={styles.searchWrap}>
          <Ionicons name="search" size={15} color={colors.textMuted} style={styles.searchIcon} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={doSearch}
            placeholder="Search songs or artists"
            placeholderTextColor={colors.textMuted}
            style={styles.searchInput}
            returnKeyType="search"
          />
        </View>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity onPress={() => setView("trending")}>
          <Text style={[styles.tab, view === "trending" && styles.tabActive]}>Trending</Text>
        </TouchableOpacity>
        {results.length > 0 && (
          <TouchableOpacity onPress={() => setView("search")}>
            <Text style={[styles.tab, view === "search" && styles.tabActive]}>Results</Text>
          </TouchableOpacity>
        )}
      </View>

      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.amber} /></View>
      ) : error ? (
        <View style={styles.center}><Text style={styles.errorText}>{error}</Text></View>
      ) : (
        <FlatList
          data={list}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 12 }}
          renderItem={({ item, index }) => (
            <TrackRow
              track={item}
              isActive={current && current.id === item.id}
              isPlaying={isPlaying}
              liked={!!liked[item.id]}
              onPress={() => playList(list, index)}
              onQueue={() => addToQueue(item)}
              onLike={() => toggleLike(item)}
            />
          )}
          ListEmptyComponent={<Text style={styles.errorText}>No tracks found</Text>}
        />
      )}

      <PlayerBar />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.ink },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: colors.line },
  searchWrap: { flex: 1, position: "relative", justifyContent: "center" },
  searchIcon: { position: "absolute", left: 12, zIndex: 1 },
  searchInput: { backgroundColor: "rgba(243,238,228,0.06)", borderWidth: 1, borderColor: colors.line, borderRadius: 20, paddingVertical: 8, paddingLeft: 34, paddingRight: 14, color: colors.paper, fontSize: 14 },
  tabs: { flexDirection: "row", gap: 20, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 4 },
  tab: { color: colors.textMuted, fontSize: 14, fontWeight: "500", paddingBottom: 6 },
  tabActive: { color: colors.paper, borderBottomWidth: 2, borderBottomColor: colors.amber },
  errorText: { color: colors.textMuted, fontSize: 14, textAlign: "center", marginTop: 40 },
  setupWrap: { flex: 1, justifyContent: "center", paddingHorizontal: 28 },
  setupTitle: { color: colors.paper, fontSize: 20, fontWeight: "500", marginBottom: 8 },
  setupBody: { color: colors.textMuted, fontSize: 14, lineHeight: 21, marginBottom: 16 },
  link: { color: colors.amber, fontSize: 14, marginBottom: 20 },
  input: { backgroundColor: "rgba(243,238,228,0.06)", borderWidth: 1, borderColor: colors.line, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, color: colors.paper, fontSize: 14, marginBottom: 12 },
  connectBtn: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 12, alignItems: "center" },
  connectBtnText: { color: colors.ink, fontWeight: "600", fontSize: 14 },
});

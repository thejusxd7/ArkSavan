import React from "react";
import { StatusBar } from "expo-status-bar";
import { PlayerProvider } from "./src/context/PlayerContext";
import HomeScreen from "./src/screens/HomeScreen";

export default function App() {
  return (
    <PlayerProvider>
      <StatusBar style="light" backgroundColor="#14110F" />
      <HomeScreen />
    </PlayerProvider>
  );
}

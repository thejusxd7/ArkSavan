# TuneHouse

A JioSaavn-style music player built with Expo/React Native, streaming real
licensed tracks via the free Jamendo API. Search, trending tracks, a queue,
likes, and a full playback bar with seek/volume.

## Get it running locally (Expo Go, fastest way to test)

You need Node.js installed. Then, in this folder:

```bash
npm install
npx expo start
```

Scan the QR code with the **Expo Go** app on your Android phone (install it
from the Play Store first). The app runs immediately — no build needed for
this step.

## Get a Jamendo API key

The app will prompt for this on first launch. Get a free client ID at
https://devportal.jamendo.com — sign up, create an app, copy the client ID.
No cost, no card required.

## Build a real installable .apk

This is the step that produces the actual file you can install without
Expo Go. It runs on Expo's free cloud build servers, so you don't need
Android Studio installed locally.

```bash
npm install -g eas-cli
eas login          # create a free Expo account if you don't have one
eas build:configure
eas build -p android --profile preview
```

`eas build:configure` will ask to generate a project ID — say yes, it
writes it into app.json for you (the placeholder in app.json gets replaced
automatically). The build takes 10-20 minutes on Expo's servers; when it
finishes, the command prints a URL where you download the `.apk` directly
to your computer or phone.

The `preview` profile in `eas.json` is set to build an `.apk` (installable
directly). The `production` profile builds an `.aab` (what you'd upload to
the Play Store instead).

## Project structure

```
App.js                      entry point, wraps app in PlayerProvider
src/
  api/jamendo.js             Jamendo API calls (trending, search)
  context/PlayerContext.js   playback state + expo-av audio engine
  components/TrackRow.js     song list item
  components/PlayerBar.js    bottom now-playing bar
  screens/HomeScreen.js      search, trending list, API key setup
  theme.js                   shared colors
```

## Extending it

- **Persistent playlists**: liked songs and queue currently reset on app
  restart. Swap the in-memory state in PlayerContext for AsyncStorage reads/
  writes to persist them.
- **Offline downloads**: `expo-file-system` can cache track audio locally.
- **Bigger catalog**: Audius (audius.org) has a similar open API with a
  larger independent-artist library if Jamendo's selection feels thin.
- **App icon/splash**: replace the placeholder paths in app.json
  (`src/assets/icon.png`) with real 1024x1024 artwork before a production
  build.
